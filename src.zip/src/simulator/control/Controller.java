package simulator.control;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import simulator.factories.Factory;
import simulator.model.Event;
import simulator.model.TrafficSimObserver;
import simulator.model.TrafficSimulator;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

public class Controller {
    private TrafficSimulator trafficSimulator;
    private Factory<Event> eventsFactory;
    public Controller(TrafficSimulator sim, Factory<Event> eventsFactory) {
        if (sim == null || eventsFactory == null) throw new IllegalArgumentException();
        else {
            this.trafficSimulator = sim;
            this.eventsFactory = eventsFactory;
        }
    }
    
    public void reset() {
    	trafficSimulator.reset();
    }

    public void loadEvents(File file) {
    	try (InputStream is = new FileInputStream(file)) {
    		JSONObject jo = new JSONObject(new JSONTokener(is));
            
            JSONArray events;

            if (jo.has("events")) {
                events = jo.getJSONArray("events");
                for (int i = 0; i < events.length(); i++) {
                    Event e = eventsFactory.create_instance(events.getJSONObject(i));
                    trafficSimulator.addEvent(e);
                }
            }
            else {
                throw new IllegalArgumentException("JSON object does not contain any events");
            }
    	}
    	catch(Exception e) {
    		throw new IllegalArgumentException(e.getMessage());
    	}
    	
    }

    public void run(int n, OutputStream out) {
        JSONObject result = new JSONObject();
        JSONArray states = new JSONArray();
        for (int i = 0; i < n; i++) {
            trafficSimulator.advance();
            states.put(trafficSimulator.report());
        }
        result.put("states", states);
        PrintStream p = new PrintStream(out);
        p.println("{\n  \"states\": [");
        for (int i = 0; i < states.length(); i++) {
            JSONObject state = states.getJSONObject(i);
            p.print(state.toString(0));
            if (i < states.length() - 1) {
                p.println(",");
            } else {
                p.println();
            }
        }
        p.println("  ]\n}");
    }
    
    public void addObserver(TrafficSimObserver o) {
    	trafficSimulator.addObserver(o);
    }
    
    public void removeObserver(TrafficSimObserver o) {
    	trafficSimulator.removeObserver(o);
    }
    
    public void addEvent(Event e) {
    	trafficSimulator.addEvent(e);
    }
    
    public int getTime() {
    	return trafficSimulator.getSimulationTime();
    }
    
    public void run(int n) {
    	for (int i=0; i<n; i++) {
    		trafficSimulator.advance();
    		try {
    			Thread.sleep(50);
    		}
    		catch(InterruptedException e) {
    			Thread.currentThread().interrupt();
    		}
    	}
    }
}
