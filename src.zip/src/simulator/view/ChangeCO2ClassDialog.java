package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import simulator.control.Controller;
import simulator.misc.Pair;
import simulator.model.SetContClassEvent;
import simulator.model.Vehicle;

public class ChangeCO2ClassDialog extends JDialog implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JComboBox<String> vehiclesSelection;
	private JSpinner co2Spinner;
	private JSpinner ticksSpinner;
	private List<Vehicle> vehicles;
	private Controller ctrl;
	
	public ChangeCO2ClassDialog(List<Vehicle> vehicles, Controller ctrl) {
		this.ctrl = ctrl;
		this.vehicles = vehicles;
		initGUI();
		setVisible(true);
	}
	
	public void initGUI() {
		JPanel mainPanel = new JPanel(new BorderLayout());
        this.setContentPane(mainPanel);
       
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
		
		vehiclesSelection = new JComboBox<>();
		
		for (Vehicle v : vehicles) {
			vehiclesSelection.addItem(v.getId());
		}
		contentPanel.add(new JLabel("Vehicle:"));
		contentPanel.add(vehiclesSelection);
		
		co2Spinner = new JSpinner(new SpinnerNumberModel(1, 0, 10, 1));
//		co2Spinner.setPreferredSize(new Dimension(50, 20));
		contentPanel.add(new JLabel("CO2 Class:"));
		contentPanel.add(co2Spinner);
		
		ticksSpinner = new JSpinner(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
//		ticksSpinner.setPreferredSize(new Dimension(50,20));
		contentPanel.add(new JLabel("Ticks:"));
		contentPanel.add(ticksSpinner);
		
		
		JPanel buttonPanel = new JPanel();
		JButton cancelButton = new JButton("Cancel");
		JButton okButton = new JButton("OK");
		cancelButton.addActionListener(this);
		okButton.addActionListener(this);
		buttonPanel.add(cancelButton);
		buttonPanel.add(okButton);
		mainPanel.add(contentPanel, BorderLayout.CENTER);
		mainPanel.add(buttonPanel, BorderLayout.SOUTH);
	
		this.setPreferredSize(new Dimension(400, 400));
        this.pack();
        this.setLocationRelativeTo(null);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String commandString = e.getActionCommand();
		if (commandString.equals("OK")) {
			String vehicleSelected = (String) vehiclesSelection.getSelectedItem();
			int co2Selected = (Integer) co2Spinner.getValue();
			int ticks = (Integer) ticksSpinner.getValue();
			
			List<Pair<String, Integer>> co2List = new ArrayList<>();
			co2List.add(new Pair<> (vehicleSelected, co2Selected));
			SetContClassEvent event = new SetContClassEvent(ctrl.getTime() + ticks, co2List);
			ctrl.addEvent(event);
		}
		else if (commandString.equals("Cancel")) {
			//close window
			System.out.println("Going back");
		}
		setVisible(false);
		dispose();
	}
}
