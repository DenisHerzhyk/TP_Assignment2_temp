package simulator.view;

import java.util.Collection;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;

public class StatusBar extends JPanel implements TrafficSimObserver {
	private static final long serialVersionUID = 1L;
	private Controller ctrl;
	private JLabel timeLabel;
	private JLabel messageLabel;
	private int newTime;
	public StatusBar(Controller ctrl) {
		this.ctrl = ctrl;
		messageLabel = new JLabel();
		ctrl.addObserver(this);
		initGUI();
	}
	
	public void initGUI() {
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		timeLabel = new JLabel("Time: none");
		messageLabel = new JLabel("No action");
		
		add(timeLabel);
		add(messageLabel);
	}

	public void updateTime(int time) {
		newTime = time;
		timeLabel.setText("Time:"+newTime);
	}
	@Override
	public void onAdvance(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		messageLabel.setText("Simulation advanced to time: " + time);
	}

	@Override
	public void onEventAdded(RoadMap map, Collection<Event> events, Event e, int time) {
		// TODO Auto-generated method stub
		messageLabel.setText("Event added: " + time);
	}

	@Override
	public void onReset(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		messageLabel.setText("Simulation reset");
	}

	@Override
	public void onRegister(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		messageLabel.setText("Simulation registered");
	}

}
