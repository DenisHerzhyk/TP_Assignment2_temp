package simulator.view;

import java.util.Collection;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;

public class StatusBar extends JPanel implements TrafficSimObserver {
	private static final long serialVersionUID = 1L;
	private Controller ctrl;
	private JLabel timeLabel;
	private JLabel messageLabel;
	private int newTime;
	public StatusBar(Controller ctrl) {
		this.ctrl = ctrl;
		initGUI();
		ctrl.addObserver(this);
	}
	
	public void initGUI() {
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		timeLabel = new JLabel("Time: 0");
		messageLabel = new JLabel("No action");
		
		add(timeLabel);
		add(Box.createHorizontalStrut(20));
		add(messageLabel);
	}

	public void updateTime(int time) {
		newTime = time;
		timeLabel.setText("Time:" + newTime);
	}
	@Override
	public void onAdvance(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			timeLabel.setText("Time:" + time);
			messageLabel.setText("Running");
		});
	}

	@Override
	public void onEventAdded(RoadMap map, Collection<Event> events, Event e, int time) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			timeLabel.setText("Time:" + time);
			messageLabel.setText("Event added:" + e.toString());
		});
	}

	@Override
	public void onReset(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			timeLabel.setText("Time:" + 0);
			messageLabel.setText("Reset");
		});
	}

	@Override
	public void onRegister(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			timeLabel.setText("Time:" + time);
			messageLabel.setText("Ready");
		});
	}

}
