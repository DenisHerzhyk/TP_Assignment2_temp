package simulator.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.io.File;
import java.io.IOException;
import java.util.Collection;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.Junction;
import simulator.model.Road;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;
import simulator.model.Vehicle;
import simulator.model.VehicleStatus;
import simulator.model.Weather;

public class MapByRoadComponent extends JComponent implements TrafficSimObserver{
	private static final long serialVersionUID = 1L;
	private static final int _JRADIUS = 10;
	private static final Color _BG_COLOR = Color.WHITE;
	private static final Color _JUNCTION_COLOR = Color.BLUE;
	private static final Color _JUNCTION_LABEL_COLOR = new Color(200, 100, 0);
	private static final Color _GREEN_LIGHT_COLOR = Color.GREEN;
	private static final Color _RED_LIGHT_COLOR = Color.RED;

	private RoadMap _map;
	private Image _car;
	private Image _sun, _wind, _storm, _rain, _cloud;
	private Image _cont1, _cont2, _cont3, _cont4, _cont5;
	
	public MapByRoadComponent(Controller ctrl) {
		initGUI();
		ctrl.addObserver(this);
	}
	
	public void initGUI() {
		_car = loadImage("car.png");
		
		_sun = loadImage("sun.png");
		_wind = loadImage("wind.png");
		_storm = loadImage("storm.png");
		_rain = loadImage("rain.png");
		_cloud = loadImage("cloud.png");
		
		_cont1 = loadImage("cont_1.png");
		_cont2 = loadImage("cont_2.png");
		_cont3 = loadImage("cont_3.png");
		_cont4 = loadImage("cont_4.png");
		_cont5 = loadImage("cont_5.png");
	}
	
	public Image getWeatherIcon(Weather w) {
		switch(w) {
		case SUNNY: return _sun;
		case CLOUDY: return _cloud;
		case RAINY: return _rain;
		case WINDY: return _wind;
		case STORM: return _storm;
		default: return _sun;
		}
	}
	
	public Image getContIcon(Road r) {
		int C = (int) Math.floor(Math.min((double) r.getTotalCO2()/(1.0 + (double) r.getContLimit()),1.0) / 0.19);
		
		switch(C) {
		case 0: return _cont1;
		case 1: return _cont2;
		case 2: return _cont3;
		case 3: return _cont4;
		case 4: return _cont5;
		default: return _cont5;
		}
	}
	
	public void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		Graphics2D g = (Graphics2D) graphics;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setColor(_BG_COLOR);
		g.clearRect(0, 0, getWidth(), getHeight());

		if (_map == null || _map.getJunctions().size() == 0) {
			g.setColor(Color.red);
			g.drawString("No road map yet!", getWidth() / 2 - 50, getHeight() / 2);
		} else {
			updatePrefferedSize();
			drawMap(g);
		}
	}

	private void drawMap(Graphics g) {
		drawRoads(g);
		drawVehicles(g);
	}

	private void drawRoads(Graphics g) {
		if (_map == null) return;
		int y = 40;
		int roadLenght = 200;
	    int lineHeight = 70;
	    int roadStartX = 60;
	    int roadEndX = roadLenght + roadStartX;
	    
		for (Road r : _map.getRoads()) {
			g.setColor(Color.BLACK);
			g.drawLine(roadStartX, y, roadEndX, y);
			g.drawString(r.getId(), 30, y);
			
			Image weatherIcon = getWeatherIcon(r.getWeather());
			g.drawImage(weatherIcon, roadStartX + roadLenght + 30, y - 10, 32, 32, this);
			Image contIcon = getContIcon(r);
			g.drawImage(contIcon, roadStartX + roadLenght + 70, y - 10, 32, 32, this);
			Color circleColor = _RED_LIGHT_COLOR;
			int idx = r.getDest().getGreenLightIndex();
			if (idx != -1 && r.equals(r.getDest().getInRoads().get(idx))) {
				circleColor = _GREEN_LIGHT_COLOR;
			}
			drawJunction(g, r.getDest(), roadEndX, y, circleColor);
			
			y+=lineHeight;			
	    }

	}

	private void drawVehicles(Graphics g) {
		int tempY = 30;
		for (Vehicle v : _map.getVehicles()) {
			if (v.getStatus() != VehicleStatus.ARRIVED) {

				Road r = v.getRoad();
	
				// The calculation below compute the coordinate (vX,vY) of the vehicle on the
				// corresponding road. It is calculated relatively to the length of the road, and
				// the location on the vehicle.
				int x1 = r.getSrc().getX();
				int y1 = r.getSrc().getY();
				int x2 = r.getDest().getX();
				int y2 = r.getDest().getY();

				double f = ((float)v.getLocation()) / r.getLength();
				int vX = (int)(x1 + (x2-x1)*f); 
				int vY = (int)(y1 + (y2-y1)*f);

				// Choose a color for the vehcile's label and background, depending on its
				// contamination class
				int vLabelColor = (int) (25.0 * (10.0 - (double) v.getContClass()));
				g.setColor(new Color(0, vLabelColor, 0));

				// draw an image of a car (with circle as background) and it identifier
				g.drawImage(_car, vX, tempY, 12, 12, this);
				g.drawString(v.getId(), vX, tempY);
				tempY+=70;
			}
		}
	}
	
	

	private void drawJunction(Graphics g, Junction j, int x, int y, Color color) {
		g.setColor(color);
	    g.fillOval(x - _JRADIUS/2, y - _JRADIUS/2, _JRADIUS, _JRADIUS);
	    
	    g.setColor(_JUNCTION_LABEL_COLOR);
	    g.drawString(j.getId(), x + _JRADIUS, y + _JRADIUS/2);
	}
	
	// this method is used to update the preffered and actual size of the component,
	// so when we draw outside the visible area the scrollbars show up
	private void updatePrefferedSize() {
		int maxW = 200;
		int maxH = 200;
		for (Junction j : _map.getJunctions()) {
			maxW = Math.max(maxW, j.getX());
			maxH = Math.max(maxH, j.getY());
		}
		maxW += 20;
		maxH += 20;
		if (maxW > getWidth() || maxH > getHeight()) {
			setPreferredSize(new Dimension(maxW, maxH));
			setSize(new Dimension(maxW, maxH));
		}
	}

	// This method draws a line from (x1,y1) to (x2,y2) with an arrow.
	// The arrow is of height h and width w.
	// The last two arguments are the colors of the arrow and the line

	// loads an image from a file
	private Image loadImage(String img) {
		Image i = null;
		try {
			return ImageIO.read(new File("resources/icons/" + img));
		} catch (IOException e) {
			throw new IllegalAccessError("Wrong path for image");
		}
	}
	
	public void update(RoadMap map) {
		_map = map;
		repaint();
	}


	@Override
	public void onAdvance(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		update(map);
	}

	@Override
	public void onEventAdded(RoadMap map, Collection<Event> events, Event e, int time) {
		// TODO Auto-generated method stub
		update(map);
	}

	@Override
	public void onReset(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		update(map);
	}

	@Override
	public void onRegister(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		update(map);
	}

}
