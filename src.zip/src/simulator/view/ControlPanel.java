package simulator.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;

public class ControlPanel extends JPanel implements TrafficSimObserver, ActionListener{
	private static final long serialVersionUID = 1L;
	private Controller ctrl;
	private boolean _stopped = true;
	private RoadMap _map;
	
	private JButton runButton, stopButton, quitButton;
	private JSpinner ticksSpinner;
	public ControlPanel(Controller ctrl) {
		this.ctrl = ctrl;
		initGUI();
		ctrl.addObserver(this);
	}
	
	public void initGUI() {
		this.setLayout(new BorderLayout());
		
	    JPanel leftButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		
		//open section
		JButton openButton = new JButton(new ImageIcon("resources/icons/open.png"));
		openButton.setToolTipText("Load Events File");
		openButton.addActionListener((e) -> loadEvents());
		leftButtonPanel.add(openButton);
		
		//co2 set section
		JButton changeCO2Button = new JButton(new ImageIcon("resources/icons/co2class.png"));
		changeCO2Button.setToolTipText("Change CO2 Class");
		changeCO2Button.addActionListener((e) -> new ChangeCO2ClassDialog(_map.getVehicles(),ctrl));
		leftButtonPanel.add(changeCO2Button);
		
		//weather set section
		JButton changeWeatherButton = new JButton(new ImageIcon("resources/icons/weather.png"));
		changeWeatherButton.setToolTipText("Change Road Weather");
		changeWeatherButton.addActionListener((e) -> new ChangeWeatherDialog(_map.getRoads(),ctrl));
		leftButtonPanel.add(changeWeatherButton);
		
		runButton = new JButton(new ImageIcon("resources/icons/run.png"));
		stopButton = new JButton(new ImageIcon("resources/icons/stop.png"));
		ticksSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 100, 1));
		leftButtonPanel.add(runButton);
		leftButtonPanel.add(stopButton);
		leftButtonPanel.add(ticksSpinner);
		stopButton.setEnabled(false);
		
		runButton.addActionListener((e) -> run());
		stopButton.addActionListener(e -> _stopped = true);
		
		add(leftButtonPanel, BorderLayout.WEST);
		
		JPanel rightButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		quitButton = new JButton(new ImageIcon("resources/icons/exit.png"));
		quitButton.addActionListener((e) -> {
			int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit?","Exit", JOptionPane.YES_NO_OPTION);
			if (option == JOptionPane.YES_OPTION) {
				System.exit(0);
			}
		});
		rightButtonPanel.add(quitButton);
		add(rightButtonPanel, BorderLayout.EAST);
	}
	
	public void loadEvents() {
		JFileChooser file = new JFileChooser();
		
		if (file.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			try {
				ctrl.reset();
				ctrl.loadEvents(file.getSelectedFile());
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(this, e.getMessage());
			}
		}
	}
	
	private void run() {
		_stopped = false;
		enableButtons(false);
		int ticks = (Integer) ticksSpinner.getValue();
		run_sim(ticks);
	}
	
	private void run_sim(int n) { 
		if (n > 0 && !_stopped) {
			try {
				ctrl.run(1);
	         	SwingUtilities.invokeLater(() -> run_sim(n - 1));
			} catch (Exception e) {
				// TODO show error message
				_stopped = true;
				enableButtons(_stopped);
				JOptionPane.showMessageDialog(this, "Coundn't run simulation: ", e.getMessage(), JOptionPane.ERROR_MESSAGE);
				// TODO enable the toolbar
			}
		} else {
			_stopped = true;
			enableButtons(_stopped);
	        // TODO enable the toolbar
		}
	}
	
	
	public void update(RoadMap map) {
		SwingUtilities.invokeLater(() -> {
			_map = map;
			System.out.println("Vehicles in map: " + (_map != null ? _map.getVehicles().size() : 0));
			repaint();
		});
	}
	
	public void enableButtons(boolean enabled) {
		runButton.setEnabled(enabled);
		stopButton.setEnabled(!enabled);
		ticksSpinner.setEnabled(enabled);
	}
	@Override
	public void onAdvance(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		update(map);
	}
	@Override
	public void onEventAdded(RoadMap map, Collection<Event> events, Event e, int time) {
		// TODO Auto-generated method stub
		update(map);
	}
	@Override
	public void onReset(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		update(map);
	}
	@Override
	public void onRegister(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		update(map);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	}
}
