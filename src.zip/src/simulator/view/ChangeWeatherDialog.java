package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import simulator.control.Controller;
import simulator.misc.Pair;
import simulator.model.Road;
import simulator.model.SetWeatherEvent;
import simulator.model.Weather;	

public class ChangeWeatherDialog extends JDialog implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JComboBox<String> roadsSelection;
	private JComboBox<Weather> weathersSelection;
	private SpinnerNumberModel ticksModel;
	private List<Road> roads;
	private Controller ctrl;

	public ChangeWeatherDialog(List<Road> roads, Controller ctrl) {
		this.roads = roads;
		this.ctrl = ctrl;
		initGUI();
		setVisible(true);
	}
	
	public void initGUI() {
		JPanel mainPanel = new JPanel(new BorderLayout());
		this.setContentPane(mainPanel);
		
		JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));

		roadsSelection = new JComboBox<>();
		for (Road r: roads) {
			roadsSelection.addItem(r.getId());
		}
		contentPanel.add(new JLabel("Road:"));
		contentPanel.add(roadsSelection);
		
		weathersSelection = new JComboBox<>(Weather.values());
		contentPanel.add(new JLabel("Weather:"));
		contentPanel.add(weathersSelection);
		
		ticksModel = new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1);
		contentPanel.add(new JLabel("Ticks:"));
        contentPanel.add(new JSpinner(ticksModel));
		
		JPanel buttonPanel = new JPanel();
		JButton cancelButton = new JButton("Cancel");
		JButton okButton = new JButton("OK");
		cancelButton.addActionListener(this);
		okButton.addActionListener(this);
		buttonPanel.add(cancelButton);
		buttonPanel.add(okButton);
		mainPanel.add(contentPanel, BorderLayout.CENTER);
		mainPanel.add(buttonPanel, BorderLayout.SOUTH);
		
		this.setPreferredSize(new Dimension(400, 400));
        this.pack();
        this.setLocationRelativeTo(null);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String commandString = e.getActionCommand();
		if (commandString.equals("OK")) {
			String roadSelected = (String) roadsSelection.getSelectedItem();
			Weather weatherSelected = (Weather) weathersSelection.getSelectedItem();
			int ticks = (Integer) ticksModel.getValue();
			
			List<Pair<String, Weather>> weatherList = new ArrayList<>();
			weatherList.add(new Pair<> (roadSelected, weatherSelected));
			SetWeatherEvent event = new SetWeatherEvent(ctrl.getTime() + ticks, weatherList);
			ctrl.addEvent(event);
		}
		else if (commandString.equals("Cancel")) {
			//close window
			System.out.println("Going back");
		}
		setVisible(false);
		dispose();
	}
}
