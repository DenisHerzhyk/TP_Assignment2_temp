package simulator.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.Junction;
import simulator.model.Road;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;
import simulator.model.Vehicle;

public class JunctionsTableModel extends AbstractTableModel implements TrafficSimObserver {
	private static final long serialVersionUID = 1L;
	private Controller ctrl;
	private List<Junction> junctions;
	private String[] columns = {"id", "Green", "Queues"};

	public JunctionsTableModel(Controller ctrl) {
		this.junctions = new ArrayList<>();
		this.ctrl = ctrl;
		ctrl.addObserver(this);
	}
	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return junctions.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columns.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		Junction j = junctions.get(rowIndex);
		if (columnIndex == 0) return j.getId();
		else if (columnIndex == 1) return j.getGreen();
		else if (columnIndex == 2) {
			StringBuilder sb = new StringBuilder();
			Map<Road, List<Vehicle>> queueMap = j.getQueue();
			for (Map.Entry<Road, List<Vehicle>> entry : queueMap.entrySet()) {
				sb.append(entry.getKey().getId()).append(":[");
				List<Vehicle> vehicles = entry.getValue();
				for (int i = 0; i < vehicles.size(); i++) {
					sb.append(vehicles.get(i).getId());
					if (i < vehicles.size() - 1) sb.append(",");
				}
				sb.append("], ");
			}
			if (sb.length() > 2) sb.setLength(sb.length() - 2);
			
			return sb.toString();
		}
		return null;
	}
	@Override
	public String getColumnName(int columnIndex) {
		return columns[columnIndex];
	}

	@Override
	public void onAdvance(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		junctions = map.getJunctions();
		fireTableDataChanged();
	}

	@Override
	public void onEventAdded(RoadMap map, Collection<Event> events, Event e, int time) {
		// TODO Auto-generated method stub
		junctions = map.getJunctions();
		fireTableDataChanged();
	}

	@Override
	public void onReset(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		junctions = map.getJunctions();
		fireTableDataChanged();
	}

	@Override
	public void onRegister(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		junctions = map.getJunctions();
		fireTableDataChanged();
	}
}
