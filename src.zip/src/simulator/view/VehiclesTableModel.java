package simulator.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;
import simulator.model.Vehicle;

public class VehiclesTableModel extends AbstractTableModel implements TrafficSimObserver {
	private static final long serialVersionUID = 1L;
	private Controller ctrl;
	private String[] columns = {"id", "Location", "Iterinary", "CO2 Class", "Max. Speed", "Speed", "Total CO2", "Distance"};
	private List<Vehicle> vehicles;
	public VehiclesTableModel(Controller ctrl) {
		this.vehicles = new ArrayList<>();
		this.ctrl = ctrl;
		ctrl.addObserver(this);
	}
	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return vehicles.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columns.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		Vehicle v = vehicles.get(rowIndex);
		switch(columnIndex) {
		case(0): return v.getId();
		case(1): return v.getLocation();
		case(2): return v.getItinerary();
		case(3): return v.getContClass();
		case(4): return v.getMaxSpeed();
		case(5): return v.getSpeed();
		case(6): return v.getTotalCO2();
		case(7): return v.getCurrDistance(v.getLocation(), v.getSpeed(), v.getRoad());
		default: return null;
		}
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		return columns[columnIndex];
	}

	@Override
	public void onAdvance(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		vehicles = map.getVehicles();
		fireTableDataChanged();
	}

	@Override
	public void onEventAdded(RoadMap map, Collection<Event> events, Event e, int time) {
		// TODO Auto-generated method stub
		vehicles = map.getVehicles();
		fireTableDataChanged();
	}

	@Override
	public void onReset(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		vehicles = map.getVehicles();
		fireTableDataChanged();
	}

	@Override
	public void onRegister(RoadMap map, Collection<Event> events, int time) {
		// TODO Auto-generated method stub
		vehicles = map.getVehicles();
		fireTableDataChanged();
	}
	

}
