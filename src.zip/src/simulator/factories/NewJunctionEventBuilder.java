package simulator.factories;

import org.json.JSONArray;
import org.json.JSONObject;
import simulator.model.DequeuingStrategy;
import simulator.model.LightSwitchingStrategy;
import simulator.model.NewJunctionEvent;
import simulator.model.Event;

public class NewJunctionEventBuilder extends Builder<Event> {
    private Factory<LightSwitchingStrategy> lssFactory;
    private Factory<DequeuingStrategy> dqsFactory;
    private int defaultIdCounter = 0;

    public NewJunctionEventBuilder(Factory<LightSwitchingStrategy> lssFactory,
                                   Factory<DequeuingStrategy> dqsFactory) {
        super("new_junction", "Creates a new junction");
        this.lssFactory = lssFactory;
        this.dqsFactory = dqsFactory;
    }

    @Override
    protected void fill_in_data(JSONObject o) {
        o.put("time", "simulation time at which the event occurs");
        o.put("id", "junction identifier");
        o.put("coor", "junction coordinates (x,y)");
        o.put("ls_strategy", "light switching strategy");
        o.put("dq_strategy", "dequeuing strategy");
    }

    @Override
    protected Event createTheInstance(JSONObject data) {
        try {
            int time = data.has("time") ? data.getInt("time") : 1;
            String id = data.has("id") ? data.getString("id") : ("junction_" + defaultIdCounter++);

            JSONArray coor = data.getJSONArray("coor");
            int xCoor = coor.getInt(0);
            int yCoor = coor.getInt(1);

            JSONObject lsStrategyJson = data.getJSONObject("ls_strategy");
            LightSwitchingStrategy lsStrategy;
            if (lsStrategyJson.has("type")) {
                lsStrategy = lssFactory.create_instance(lsStrategyJson);
            } else {
                JSONObject wrapped = new JSONObject();
                wrapped.put("type", "round_robin_lss");
                wrapped.put("data", lsStrategyJson);
                lsStrategy = lssFactory.create_instance(wrapped);
            }

            JSONObject dqStrategyJson = data.getJSONObject("dq_strategy");
            DequeuingStrategy dqStrategy;
            if (dqStrategyJson.has("type")) {
                dqStrategy = dqsFactory.create_instance(dqStrategyJson);
            } else {
                JSONObject wrapped = new JSONObject();
                wrapped.put("type", "move_first_dqs");
                wrapped.put("data", dqStrategyJson);
                dqStrategy = dqsFactory.create_instance(wrapped);
            }

            return new NewJunctionEvent(time, id, lsStrategy, dqStrategy, xCoor, yCoor);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid data for new junction: " + e.getMessage(), e);
        }
    }
}