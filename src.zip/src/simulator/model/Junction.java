package simulator.model;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class Junction extends SimulatedObject {
    private List<Road> incomingRoads;
    private Map<Junction, Road> outgoingRoads;
    private List<List<Vehicle>> listOfQueues;
    private Map<Road, List<Vehicle>> roadQueueMap;
    private int greenIndex;
    private int lastSwitch;
    private LightSwitchingStrategy lightSwitchingStrategy;
    private DequeuingStrategy dequeuingStrategy;
    private int x, y;

    Junction(String id, LightSwitchingStrategy lsStrategy, DequeuingStrategy dqStrategy, int xCoor, int yCoor) {
        super(id);
        if (lsStrategy == null) throw new IllegalArgumentException("Null light switching strategy");
        if (dqStrategy == null) throw new IllegalArgumentException("Null dequeuing strategy");
        if (xCoor < 0 || yCoor < 0) throw new IllegalArgumentException("xCoor or yCoor less than 0");

        this.lightSwitchingStrategy = lsStrategy;
        this.dequeuingStrategy = dqStrategy;
        this.x = xCoor;
        this.y = yCoor;
        this.greenIndex = -1;
        this.lastSwitch = 0;
        this.incomingRoads = new ArrayList<>();
        this.outgoingRoads = new HashMap<>();
        this.listOfQueues = new ArrayList<>();
        this.roadQueueMap = new HashMap<>();
    }

    void addIncomingRoad(Road r) {
        if (r == null) throw new IllegalArgumentException("Road cannot be null");
        if (!r.getDest().equals(this)) throw new IllegalArgumentException("Road destination must be this junction");

        if (incomingRoads.contains(r)) {
            return;
        }
        incomingRoads.add(r);
        List<Vehicle> queue = new ArrayList<>();
        listOfQueues.add(queue);
        roadQueueMap.put(r, queue);
    }

    void addOutgoingRoad(Road r) {
        if (r == null) throw new IllegalArgumentException("Road cannot be null");
        if (!r.getSrc().equals(this)) throw new IllegalArgumentException("Road source must be this junction");
        if (outgoingRoads.containsValue(r.getSrc())) throw new IllegalArgumentException("Road destination already exists");

        outgoingRoads.put(r.getDest(), r);
    }

    void enter(Vehicle v) {
        if (v == null) {
            throw new IllegalArgumentException("Vehicle cannot be null");
        }
        Road currRoad = v.getRoad();
        if (!roadQueueMap.containsKey(currRoad)) {
            throw new IllegalArgumentException(v + " has not been added");
        }
        roadQueueMap.get(currRoad).add(v);
    }

    Road roadTo(Junction j) {
        return outgoingRoads.get(j);
    }

    @Override
    protected void advance(int time) {
        if (greenIndex != -1) {
            Road roadWithGreen = incomingRoads.get(greenIndex);
            List<Vehicle> queue = roadQueueMap.get(roadWithGreen);
            List<Vehicle> vehicleToMove = dequeuingStrategy.dequeue(queue);

            for (Vehicle v : vehicleToMove) {
                v.moveToNextRoad();
                queue.remove(v);
            }
        }

        int nextGreen = lightSwitchingStrategy.chooseNextGreen(incomingRoads, listOfQueues, greenIndex, lastSwitch, time);
        if (nextGreen != greenIndex) {
            greenIndex = nextGreen;
            lastSwitch = time;
        }
    }

    @Override
    public JSONObject report() {
        JSONObject json = new JSONObject();
        json.put("id", getId());
        if (greenIndex == -1 || incomingRoads.isEmpty()) {
            json.put("green", "none");
        } else {
            json.put("green", incomingRoads.get(greenIndex).getId());
        }

        JSONArray queues = new JSONArray();
        for (int i = 0; i < incomingRoads.size(); i++) {
            JSONObject q = new JSONObject();
            q.put("road", incomingRoads.get(i).getId());
            JSONArray vehicles = new JSONArray();
            for (Vehicle v : listOfQueues.get(i)) {
                vehicles.put(v.getId());
            }
            q.put("vehicles", vehicles);
            queues.put(q);
        }
        json.put("queues", queues);
        return json;
    }
    
    public String getGreen() {
    	if (greenIndex != -1 && greenIndex < incomingRoads.size()) return incomingRoads.get(greenIndex).getId();
    	return "NONE";
    }
    
    public List<Road> getInRoads() {
    	return incomingRoads;
    }
    
    public int getGreenLightIndex() {
    	return greenIndex;
    }
    
    public Map<Road, List<Vehicle>> getQueue() {
    	return roadQueueMap;
    }
    
    public int getX() {return x;}
    
    public int getY() {return y;}
    
    public void setX(int newX) { x = newX;}
    public void setY(int newY) {y = newY;}
}