package simulator.model;

import simulator.misc.Pair;

import java.util.List;

public class SetContClassEvent extends Event {
    List<Pair<String, Integer>> cs;
    public SetContClassEvent(int time, List<Pair<String,Integer>> cs)  {
        super(time);
        if (cs == null) throw new IllegalArgumentException("cs is null");
        this.cs = cs;
    }

    @Override
    void execute(RoadMap map) {
        for (Pair<String, Integer> c : cs) {
            Vehicle v = map.getVehicle(c.getFirst());
            if (v == null) throw new IllegalArgumentException("vehicle is null");
            v.setContClass(c.getSecond());
        }
    }
    
    // should be updated to id
    @Override
    public String toString() {
    	return "New Vehicle + '" + getContClass() + "'";
    }
    
    public List<Pair<String, Integer>> getContClass () {
    	return cs;
    }
}
