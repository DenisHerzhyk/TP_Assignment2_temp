package simulator.model;

public class CityRoad extends Road {

    CityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
        super(id, srcJunc, destJunc, maxSpeed, contLimit, length, weather);
        if (maxSpeed <= 0) throw new IllegalArgumentException("Max speed must be positive");
        if (length <= 0) throw new IllegalArgumentException("Length must be positive");
        if (contLimit <= 0) throw new IllegalArgumentException("Contamination limit must be positive");
    }

    @Override
    public void reduceTotalContamination() {
        int reduce;
        if (totalCont < 0) throw new IllegalArgumentException("The total contamination cannot be negative");
        if (contLimit < 0) throw new IllegalArgumentException("Contlimit must be positive");
        if (weather == Weather.WINDY || weather == Weather.STORM) reduce = 10;
        else reduce = 2;

        totalCont = Math.max(0, totalCont - reduce);
    }

    @Override
    public void updateSpeedLimit() {
        currentSpeedLimit = maxSpeed;
    }

    @Override
    public int calculateVehicleSpeed(Vehicle v) {
        return (int) (((11.0 - v.getContClass()) / 11.0) * currentSpeedLimit);
    }

}