package simulator.model;

public class InterCityRoad extends Road{
    InterCityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
        super(id, srcJunc, destJunc, maxSpeed, contLimit, length, weather);
        if (length < 0) throw new IllegalArgumentException("length < 0");
        if (contLimit < 0) throw new IllegalArgumentException("contLimit must be a positive number");
        if (maxSpeed <= 0) throw new IllegalArgumentException("maxSpeed must be greater than 0");
        srcJunc.addOutgoingRoad(this);
        destJunc.addIncomingRoad(this);
    }

    @Override
    public void reduceTotalContamination() {
        totalCont = (int) (((100.0 - weather.getX()) / 100.0) * totalCont);
    }

    @Override
    public void updateSpeedLimit() {
        if (contLimit < 0) throw new IllegalArgumentException("contLimit must be a positive number");
        if (maxSpeed <= 0) throw new IllegalArgumentException("maxSpeed must be greater than 0");
        if (getTotalCO2() > getContLimit()) {
            setSpeedLimit(getMaxSpeed() / 2);
        }
        else {
            setSpeedLimit(getMaxSpeed());
        }
    }

    @Override
    public int calculateVehicleSpeed(Vehicle v) {
        int speedLimit = getSpeedLimit();
        if (getWeather() == Weather.STORM) {
            speedLimit = (speedLimit * 8) / 10;
        }
        return speedLimit;
    }
}
