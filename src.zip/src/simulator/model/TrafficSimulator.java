package simulator.model;

import org.json.JSONObject;
import simulator.misc.SortedArrayList;

import java.util.*;

public class TrafficSimulator implements Observable<TrafficSimObserver> {
    private RoadMap roadMap;
    private List<Event> eventList;
    private List<TrafficSimObserver> observers;
    private int simulationTime;

    public TrafficSimulator() {
        roadMap = new RoadMap();
        eventList = new SortedArrayList<>();
        observers = new ArrayList<>();
        this.simulationTime = 0;
    }

    public void addEvent(Event e) {
        if (e == null) throw new RuntimeException("Attempted to add null event");
        eventList.add(e);
        for (TrafficSimObserver ob: observers) {
        	ob.onEventAdded(roadMap, eventList, e, simulationTime);
        }
    }

    public void advance() {
        simulationTime++;
        try {
            Iterator<Event> it = eventList.iterator();
            while(it.hasNext()) {
                Event e = it.next();
                if (e._time == simulationTime) {
                    it.remove();
                    try {
                        e.execute(roadMap);
                    } catch (Exception ex) {
                        throw ex;
                    }
                }
            }

            for (Junction j : roadMap.getJunctions()) {
                j.advance(simulationTime);
            }
            for(Road r : roadMap.getRoads()) {
                r.advance(simulationTime);
            }
            for (TrafficSimObserver ob : observers) {
            	ob.onAdvance(roadMap, eventList, simulationTime);
            }
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void reset() {
        roadMap.reset();
        eventList.clear();
        simulationTime = 0;
        for (TrafficSimObserver ob: observers) {
        	ob.onReset(roadMap, eventList, simulationTime);
        }
    }

    public JSONObject report() {
        JSONObject json = new JSONObject();
        json.put("time", simulationTime);
        json.put("state", roadMap.report());
        return json;
    }


    public void addObserver(TrafficSimObserver o) {
        observers.add(o);
        o.onRegister(roadMap, eventList, simulationTime);
    }

    public void removeObserver(TrafficSimObserver o) {
        observers.remove(o);
    }
    
    public int getSimulationTime() {
    	return simulationTime;
    }
}
