package simulator.model;

public class NewCityRoadEvent extends NewRoadEvent {

    private String id;
    private String srcJunction;
    private String destJunction;
    private int length;
    private int co2Limit;
    private int maxSpeed;
    private Weather weather;

    public NewCityRoadEvent(int time, String id, String srcJun, String destJunc, int length, int co2Limit, int maxSpeed, Weather weather) {

        super(time, id, srcJun, destJunc,length, co2Limit,maxSpeed, weather);

        if(time < 0) throw new IllegalArgumentException("Time cannot be negative.");
        if(length < 0) throw new IllegalArgumentException("Length cannot be negative.");
        if(co2Limit < 0) throw new IllegalArgumentException("CO2 limit cannot be negative.");
        if(maxSpeed <= 0) throw new IllegalArgumentException("Max speed must be a positive number.");
        if(weather == null) throw new IllegalArgumentException("Weather condition cannot be null.");

        this.id = id;
        srcJunction = srcJun;
        destJunction = destJunc;
        this.length = length;
        this.co2Limit = co2Limit;
        this.maxSpeed = maxSpeed;
        this.weather = weather;
    }

    @Override
    public String toString() {
        return "New City Road '" + getId() + "'";
    }

    @Override
    Road createRoadObject() {
        Junction src = map.getJunction(srcJunction);
        Junction dest = map.getJunction(destJunction);
        if (src == null || dest == null) {
            throw new IllegalArgumentException("Source or destination junction not found");
        }
        Road road = new CityRoad(id, src, dest, maxSpeed, co2Limit, length, weather);

        src.addOutgoingRoad(road);
        dest.addIncomingRoad(road);

        return road;
    }
    
    public String getId() {
    	return id;
    }
}
