package simulator.model;

public abstract class Event implements Comparable<Event> {
    protected int _time;

    Event(int time) {
        if ( time < 1 )
            throw new IllegalArgumentException("Time must be positive (" + time + ")");
        else {
            _time = time;
        }
    }

    public int getTime() {
        return _time;
    }

    @Override
    public int compareTo(Event o) {
        // TODO complete the method to compare events according to their _time, and when
        // _time is equal it compares the _time_stamp;

        return Integer.compare(_time, o._time);
    }

    abstract void execute(RoadMap map);
}