package simulator.model;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Vehicle extends SimulatedObject {
    private int currSpeed;
    private int maxSpeed;
    private int contClass;
    private List<Junction> itinerary;
    private VehicleStatus status;
    private int location;
    private int currLocation;
    private Road road;
    private int totalCont;
    private int totalDistance;
    private int itineraryIndex;

    Vehicle(String id, int maxSpeed, int contClass, List<Junction> itinerary) {
        super(id);
        if (id == null) {
            throw new IllegalArgumentException("Vehicle ID cannot be empty or null");
        }
        if ( contClass < 0 || contClass > 10 ) throw new IllegalArgumentException("contClass must be between 0 and 10");
        if (maxSpeed <= 0) throw new IllegalArgumentException("maxSpeed must be a positive number");
        if (itinerary.size() < 2 || itinerary == null) throw new IllegalArgumentException("itinerary must contain at least two junction");

        this.maxSpeed = maxSpeed;
        this.contClass = contClass;
        this.itinerary = Collections.unmodifiableList(new ArrayList<>(itinerary));
        this.currSpeed = 0;
        this.location = 0;
        this.currLocation = 0;
        this.totalCont = 0;
        this.totalDistance = 0;
        this.status = VehicleStatus.PENDING;
        this.road = null;
        this.itineraryIndex = 0;
    }

    @Override
    public JSONObject report() {
        JSONObject json = new JSONObject();
        json.put("id", getId());
        json.put("speed", currSpeed);
        json.put("distance", totalDistance);
        json.put("co2", totalCont);
        json.put("class", contClass);
        json.put("status", status.toString().toUpperCase());

        if (status == VehicleStatus.TRAVELING) {
            json.put("road", road.getId());
            json.put("location", location);
        }

        return json;
    }

    void setSpeed(int s) {
        if (s < 0) throw new IllegalArgumentException("speed must be a positive number");
        if (status == VehicleStatus.TRAVELING) {
            this.currSpeed = Math.min(s, maxSpeed);
        }
        else {
            this.currSpeed = 0;
        }
    }

    void setContClass(int c) {
        if (c < 0 || c > 10 ) throw new IllegalArgumentException("contClass must be between 0 and 10");
        this.contClass = c;
    }
    //new functions
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vehicle vehicle = (Vehicle) o;
        return getId().equals(vehicle.getId());
    }

    @Override
    public int hashCode() {
        return getId().hashCode();
    }

    @Override
    protected void advance(int time) {
        if (status != VehicleStatus.TRAVELING) {
        	currSpeed = 0; 
        	return;
        }

        int distanceTraveled = getCurrDistance(location, currSpeed, road);
        int c = contClass * distanceTraveled;
        location = Math.min(location+currSpeed, road.getLength());

        totalCont += c;
        totalDistance += distanceTraveled;

        road.addContamination(c);

        if (location >= road.getLength()) {
            status = VehicleStatus.WAITING;
            currSpeed = 0;
            road.getDest().enter(this);
        }
        System.out.printf("Vehicle %s moving from %d to %d on road %s%n",
        	    getId(), currLocation, location, road.getId());
    }

    void moveToNextRoad() {
        if (status != VehicleStatus.PENDING && status != VehicleStatus.WAITING) {
            throw new IllegalArgumentException("Vehicle must be waiting in queue.");
        }
        if (status == VehicleStatus.PENDING) {
            if (itinerary == null || itinerary.size() < 2) {
                throw new IllegalStateException("Itinerary must contain at least 2 junctions");
            }

            Junction firstJunction = itinerary.get(0);
            Junction secondJunction = itinerary.get(1);

            road = firstJunction.roadTo(secondJunction);

            if (road == null) {
                for (Road r : Road.getAllRoads()) {
                    if (r.getSrc().equals(firstJunction) && r.getDest().equals(secondJunction)) {
                        road = r;
                        firstJunction.addOutgoingRoad(road);
                        secondJunction.addIncomingRoad(road);
                        break;
                    }
                }
            }
            if (road == null) {
                throw new IllegalStateException("No road exists between junctions");
            }
            location = 0;
            currSpeed = 0;
            road.enter(this);
            currSpeed = maxSpeed;
            status = VehicleStatus.TRAVELING;
            itineraryIndex = 1;
            return;
        }
        if (itineraryIndex == itinerary.size() - 1) {
            road.exit(this);
            status = VehicleStatus.ARRIVED;
            currSpeed = 0;
            road = null;
        } else {
            location = 0;
            road.exit(this);
            Junction nextJunction = itinerary.get(itineraryIndex + 1);
            road = itinerary.get(itineraryIndex).roadTo(nextJunction);

            if (road == null) {
                throw new IllegalStateException("No road to next junction");
            }

            currSpeed = 0;
            road.enter(this);
            currSpeed = maxSpeed;
            status = VehicleStatus.TRAVELING;
            itineraryIndex++;
        }
    }
    public int getCurrDistance(int currlocation, int currSpeed, Road road) {
        return Math.min(currSpeed, road.getLength() - currLocation);
    }
    public int getLocation() {return location;}
    public int getCurrLocation() {return currLocation;}
    public int getSpeed() {return currSpeed;}
    public int getMaxSpeed() {return maxSpeed;}
    public int getContClass() {return contClass;}
    public List<Junction> getItinerary() {return itinerary;}
    public VehicleStatus getStatus() {return status;}
    public int getTotalCO2() {return totalCont;}
    public Road getRoad() {return road;}

}