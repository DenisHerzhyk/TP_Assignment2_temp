package simulator.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public abstract class Road extends SimulatedObject {
    private static List<Road> allRoads = new ArrayList<>();
    private Junction srcJunc;
    private Junction destJunc;
    int maxSpeed;
    int contLimit;
    private int length;
    Weather weather;
    int totalCont;
    int currentSpeedLimit;
    private List<Vehicle> vehicles;

    Road(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
        super(id);

        if (maxSpeed <= 0) throw new IllegalArgumentException("maxSpeed must be a positive number");
        if (contLimit < 0) throw new IllegalArgumentException("contLimit must be non-negative");
        if (length <= 0) throw new IllegalArgumentException("length must be a positive number");
        if (srcJunc == null || destJunc == null || weather == null)
            throw new IllegalArgumentException("junctions or weather must not be null");

        this.srcJunc = srcJunc;
        this.destJunc = destJunc;
        this.maxSpeed = maxSpeed;
        this.contLimit = contLimit;
        this.length = length;
        this.weather = weather;
        this.totalCont = 0;
        this.currentSpeedLimit = maxSpeed;
        this.vehicles = new ArrayList<>();
        allRoads.add(this);
    }

    void enter(Vehicle v) {
        if (v.getSpeed() != 0 || v.getLocation() != 0)
            throw new IllegalArgumentException("Vehicle must be stopped at location 0 to enter the road.");
        vehicles.add(v);
    }

    void exit(Vehicle v) {
        vehicles.remove(v);
    }

    public static void clearAllRoads() {
        allRoads.clear();
    }

    void setWeather(Weather w) {
        if (w == null) throw new IllegalArgumentException("weather must not be null");
        weather = w;
    }

    void addContamination(int c) {
        if (c < 0) c = 0;
        totalCont += c;
    }

    public abstract void reduceTotalContamination();
    public abstract void updateSpeedLimit();
    public abstract int calculateVehicleSpeed(Vehicle v);

    @Override
    protected void advance(int time) {
        reduceTotalContamination();
        updateSpeedLimit();

        for (Vehicle v : vehicles) {
            int oldSpeed = v.getSpeed();
            v.setSpeed(calculateVehicleSpeed(v));
            v.advance(time);

            if (v.getSpeed() != oldSpeed) {
                int contamination = v.getContClass() * (v.getSpeed() - oldSpeed);
                addContamination(contamination);
            }
        }

        vehicles.sort(Comparator.comparingInt(Vehicle::getLocation).reversed());
    }

    @Override
    public JSONObject report() {
        JSONObject jo = new JSONObject();
        jo.put("id", _id);
        jo.put("speedlimit", currentSpeedLimit);
        jo.put("weather", weather.toString());
        jo.put("co2", totalCont);

        JSONArray vehiclesArray = new JSONArray();
        for (Vehicle v : vehicles) {
            vehiclesArray.put(v.getId());
        }
        jo.put("vehicles", vehiclesArray);
        return jo;
    }

    public int getSpeedLimit() {
        return currentSpeedLimit;
    }

    public Weather getWeather() {
        return weather;
    }

    public int getLength() {
        return length;
    }

    public Junction getDest() {
        return destJunc;
    }

    public Junction getSrc() {
        return srcJunc;
    }

    public int getContLimit() {
        return contLimit;
    }

    public int getMaxSpeed() {
        if (maxSpeed <= 0) throw new IllegalArgumentException("maxSpeed must be a positive number");
        return maxSpeed;
    }

    public int getTotalCO2() {
        return totalCont;
    }

    public List<Vehicle> getVehicles() {
        return Collections.unmodifiableList(vehicles);
    }

    public void setTotalCO2(int totalCO2) {
        totalCont = totalCO2;
    }

    public void setSpeedLimit(int speedLimit) {
        currentSpeedLimit = speedLimit;
    }

    public static List<Road> getAllRoads() {
        return Collections.unmodifiableList(allRoads);
    }
}