package simulator.model;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

public class NewVehicleEvent extends Event{
    private String id;
    private int maxSpeed;
    private int contClass;
    private List<String> itinerary;
    public NewVehicleEvent(int time, String id, int maxSpeed, int contClass, List<String> itinerary) {
        super(time);
        this.id = id;
        this.maxSpeed = maxSpeed;
        this.contClass = contClass;
        this.itinerary = itinerary;
    }

    @Override
    void execute(RoadMap map) {
        List<Junction> itin = new ArrayList<Junction>();

        for (String jun_id: itinerary) {
            try {
                Junction jn = map.getJunction(jun_id);
                if (jn != null) {
                    itin.add(jn);
                }
                else {
                    throw new IllegalArgumentException("Junction not found: " + jun_id);
                }
            }
            catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            }
        }
        Vehicle vehicle = new Vehicle(id, maxSpeed, contClass, itin);
        map.addVehicle(vehicle);
        vehicle.moveToNextRoad();
        
        //delete later 
        JFrame frame = new JFrame("Frame");
    }
    
    @Override
    public String toString() {
    	return "New Vehicle " + getId() + "'";
    }
    
    public String getId() {
    	return id;
    }
}
