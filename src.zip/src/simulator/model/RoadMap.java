package simulator.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;

public class RoadMap {
    private List<Junction> junctions;
    private List<Road> roads;
    private List<Vehicle> vehicles;
    private Map<String, Junction> junctionsMap;
    private Map<String, Road> roadsMap;
    private Map<String, Vehicle> vehiclesMap;

    public RoadMap() {
        this.junctions = new ArrayList<>();
        this.roads = new ArrayList<>();
        this.vehicles = new ArrayList<>();
        this.junctionsMap = new HashMap<>();
        this.roadsMap = new HashMap<>();
        this.vehiclesMap = new HashMap<>();
    }

    void addJunction(Junction j) {
        if (junctionsMap.containsKey(j.getId())) throw new IllegalArgumentException("Junction with id " + j.getId() + " already exists");
        junctions.add(j);
        junctionsMap.put(j.getId(), j);
    }

    void addRoad(Road r) {
        if (roadsMap.containsKey(r.getId())) throw new IllegalArgumentException(r + " has already been added");
        if (!junctionsMap.containsKey(r.getSrc().getId()) || !junctionsMap.containsKey(r.getDest().getId())) throw new IllegalArgumentException(r + " must exist in RoadMap");
        roads.add(r);
        roadsMap.put(r.getId(), r);

        Junction src = junctionsMap.get(r.getSrc().getId());
        Junction dest = junctionsMap.get(r.getDest().getId());
        src.addOutgoingRoad(r);
        dest.addIncomingRoad(r);
    }

    void addVehicle(Vehicle v) {
        if (vehiclesMap.containsKey(v.getId())) throw new IllegalArgumentException(v + " has already been added");
        if (v.getId() == null) throw new IllegalArgumentException(v + " has no id");

        List<Junction> itinerary = v.getItinerary();
        for (int i = 0; i < itinerary.size() - 1; i++) {
            Junction src = itinerary.get(i);
            Junction dest = itinerary.get(i + 1);
            boolean roadExists = false;

            for (Road r : roads) {
                if (r.getSrc().equals(src) && r.getDest().equals(dest)) {
                    roadExists = true;
                    break;
                }
            }

            if (!roadExists) {
                throw new IllegalArgumentException("No road exists between " +
                        src.getId() + " and " + dest.getId());
            }
        }
        vehicles.add(v);
        vehiclesMap.put(v.getId(), v);
    }

    public Junction getJunction(String id) {
        if (junctionsMap.get(id) == null) return null;
        return junctionsMap.get(id);
    }

    public Road getRoad(String id) {
        if (roadsMap.get(id) == null) return null;
        return roadsMap.get(id);
    }

    public Vehicle getVehicle(String id) {
        if (vehiclesMap.get(id) == null) return null;
        return vehiclesMap.get(id);
    }

    public List<Junction> getJunctions() {return Collections.unmodifiableList(junctions);}

    public List<Road> getRoads() {return Collections.unmodifiableList(roads);}

    public List<Vehicle> getVehicles() {return Collections.unmodifiableList(vehicles);}

    void reset() {
        junctions.clear();
        roads.clear();
        vehicles.clear();
        junctionsMap.clear();
        roadsMap.clear();
        vehiclesMap.clear();
    }

    public JSONObject report() {
        JSONObject json = new JSONObject();

        JSONArray jArray = new JSONArray();
        for(Junction j : junctions) {
            jArray.put(j.report());
        }
        json.put("junctions", jArray);

        JSONArray rArray = new JSONArray();
        for(Road r : roads) {
            rArray.put(r.report());
        }
        json.put("roads", rArray);

        JSONArray vArray = new JSONArray();
        for(Vehicle v : vehicles) {
            vArray.put(v.report());
        }
        json.put("vehicles", vArray);
        return json;
    }

}
